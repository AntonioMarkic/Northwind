<?php

$connect = mysqli_connect("localhost", "root", "", "hr_debt");
$output = '';
if(isset($_GET["flname"]))
{
	$search = mysqli_real_escape_string($connect, $_GET["flname"]);
	$query = "
	SELECT * FROM employees 
	WHERE first_name LIKE '%".$search."%' OR last_name LIKE '%".$search."%' ORDER BY last_name
	";
}
else
{
	$query = "
	SELECT * FROM employees ORDER BY last_name";
}
$result = mysqli_query($connect, $query);
$response = array();

while($row = mysqli_fetch_assoc($result)){

    $response[] = $row;
}

echo json_encode($response);
exit;