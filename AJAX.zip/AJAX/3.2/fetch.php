<?php
$connect = mysqli_connect("localhost", "root", "", "hr_debt");
$output = '';
if(isset($_POST["query"]))
{
	$search = mysqli_real_escape_string($connect, $_POST["query"]);
	$query = "
	SELECT * FROM employees 
	WHERE birth_date LIKE '%".$search."%'
	OR first_name LIKE '%".$search."%' 
	OR last_name LIKE '%".$search."%' 
	OR gender LIKE '%".$search."%' 
	OR hire_date LIKE '%".$search."%'
	";
}
else
{
	$query = "
	SELECT * FROM employees ORDER BY emp_no";
}
$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
	$output .= '<div class="table-responsive">
					<table class="table table bordered">
						<tr>
							<th>Birth data</th>
							<th>First name</th>
							<th>Last name</th>
							<th>Gender</th>
							<th>Hire date</th>
						</tr>';
	while($row = mysqli_fetch_array($result))
	{
		$output .= '
			<tr>
				<td>'.$row["birth_date"].'</td>
				<td>'.$row["first_name"].'</td>
				<td>'.$row["last_name"].'</td>
				<td>'.$row["gender"].'</td>
				<td>'.$row["hire_date"].'</td>
			</tr>
		';
	}
	echo $output;
}
else
{
	echo 'Data Not Found';
}
?>