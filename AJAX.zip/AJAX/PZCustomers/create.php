<?php
require 'db.php';
$message = '';
if (isset($_POST['CustomerID']) && isset ($_POST['CompanyName'])  && isset($_POST['ContactName'])  && isset($_POST['ContactTitle']) && isset($_POST['Address']) && isset($_POST['City']) && isset($_POST['Region']) && isset($_POST['PostalCode'])&& isset($_POST['Country']) && isset($_POST['Phone']) && isset($_POST['Fax'])) {
  $CustomerID = $_POST['CustomerID'];
  $CompanyName = $_POST['CompanyName'];
  $ContactName = $_POST['ContactName'];
  $ContactTitle = $_POST['ContactTitle'];
  $Address = $_POST['Address'];
  $City = $_POST['City'];
  $Region = $_POST['Region'];
  $PostalCode = $_POST['PostalCode'];
  $Country = $_POST['Country'];
  $Phone = $_POST['Phone'];
  $Fax = $_POST['Fax'];
  $sql = 'INSERT INTO customers(CustomerID, CompanyName, ContactName, ContactTitle, Address, City, Region, PostalCode, Country, Phone, Fax) VALUES(:CustomerID, :CompanyName, :ContactName, :ContactTitle, :Address, :City, :Region, :PostalCode, :Country, :Phone, :Fax)';
  $statement = $connection->prepare($sql);
  if ($statement->execute([':CustomerID' => $CustomerID, ':CompanyName' => $CompanyName, ':ContactName' => $ContactName, ':ContactTitle' => $ContactTitle,':Address' => $Address,':City' => $City,':Region' => $Region,':PostalCode' => $PostalCode,':Country' => $Country,':Phone' => $Phone,':Fax' => $Fax])) {
    $message = 'data inserted successfully';
  }



}


 ?>
<?php require 'headerCustomer.php'; ?>
<div class="container">
  <div class="card mt-5">
    <div class="card-header">
      <h2>Create customer</h2>
    </div>
    <div class="card-body">
      <?php if(!empty($message)): ?>
        <div class="alert alert-success">
          <?= $message; ?>
        </div>
      <?php endif; ?>
      <form method="post">
        <div class="form-group">
          <label for="CustomerID">Customer ID</label>
          <input type="text"  name="CustomerID" id="CustomerID" class="form-control">
        </div>
        <div class="form-group">
          <label for="CompanyName">Company Name</label>
          <input type="text" name="CompanyName" id="CompanyName" class="form-control">
        </div>
        <div class="form-group">
          <label for="ContactName">Contact Name</label>
          <input type="text" name="ContactName" id="ContactName" class="form-control">
        </div>
        <div class="form-group">
          <label for="ContactTitle">Contact Title</label>
          <input type="text" name="ContactTitle" id="ContactTitle" class="form-control">
        </div>
        <div class="form-group">
          <label for="Address">Address</label>
          <input type="text" name="Address" id="Address" class="form-control">
        </div><div class="form-group">
          <label for="City">City</label>
          <input type="text" name="City" id="City" class="form-control">
        </div>
        <div class="form-group">
          <label for="Region">Region</label>
          <input type="text" name="Region" id="Region" class="form-control">
        </div><div class="form-group">
          <label for="PostalCode">Postal Code</label>
          <input type="text" name="PostalCode" id="PostalCode" class="form-control">
        </div><div class="form-group">
          <label for="Country">Country</label>
          <input type="text" name="Country" id="Country" class="form-control">
        </div>
        <div class="form-group">
          <label for="Phone">Phone</label>
          <input type="text" name="Phone" id="Phone" class="form-control">
        </div><div class="form-group">
          <label for="Fax">Fax</label>
          <input type="text" name="Fax" id="Fax" class="form-control">
        </div>		
        <div class="form-group">
          <button type="submit" class="btn btn-info">Create customer</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php require 'footer.php'; ?>