<?php
require 'db.php';
$CustomerID = $_GET['CustomerID'];
$sql = 'DELETE FROM customers WHERE CustomerID=:CustomerID';
$statement = $connection->prepare($sql);
if ($statement->execute([':CustomerID' => $CustomerID])) {
  header("Location: /AJAX/PZCustomers/indexCustomer.php");
}