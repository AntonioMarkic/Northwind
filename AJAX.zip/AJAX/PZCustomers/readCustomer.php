<?php
require 'db.php';
$CustomerID = $_GET['CustomerID'];
$sql = 'SELECT * FROM customers WHERE CustomerID=:CustomerID';
$statement = $connection->prepare($sql);
$statement->execute([':CustomerID' => $CustomerID ]);
$row = $statement->fetch(PDO::FETCH_OBJ);
 ?>
<?php require 'headerCustomer.php'; ?>
<div class="container">
  <div class="card mt-5">
    <div class="card-header">
      <h2>Customer:</h2>
    </div>
    <div class="card-body">
      <?php if(!empty($message)): ?>
        <div class="alert alert-success">
          <?= $message; ?>
        </div>
      <?php endif; ?>
      <form method="post">
        <div class="form-group">
          <h2 class="text">CustomerID: <?= $row->CustomerID;?></h2>
        </div>
        <div class="form-group">
          <h2 class="text">Company Name: <?= $row->CompanyName; ?></h2>
        </div>
        <div class="form-group">
          <h2 class="text">Contact Name: <?=$row->ContactName;  ?></h2>
        </div>
		<div class="form-group">
          <h2 class="text">Contact Title: <?=$row->ContactTitle;  ?></h2>
        </div>
        <div class="form-group">
          <h2 class="text">Addres: <?= $row->Address; ?></h2>
        </div>
        <div class="form-group">
          <h2 class="text">City: <?= $row->City; ?></h2>
        </div><div class="form-group">
          <h2 class="text">Region: <?= $row->Region; ?></h2>
        </div>
        <div class="form-group">
          <h2 class="text">Postal Code: <?= $row->PostalCode; ?></h2>
		<div class="form-group">
          <h2 class="text">Country: <?= $row->Country; ?></h2>
		<div class="form-group">
          <h2 class="text">Phone: <?= $row->Phone; ?></h2>
		  <div class="form-group">
          <h2 class="text">Fax: <?= $row->Fax; ?></h2>
      </form>
    </div>
  </div>
</div>
<?php require 'footer.php'; ?>
