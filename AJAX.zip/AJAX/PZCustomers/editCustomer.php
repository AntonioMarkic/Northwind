<?php
require 'db.php';
$CustomerID = $_GET['CustomerID'];
$sql = 'SELECT * FROM customers WHERE CustomerID=:CustomerID';
$statement = $connection->prepare($sql);
$statement->execute([':CustomerID' => $CustomerID ]);
$customers = $statement->fetch(PDO::FETCH_OBJ);
if (isset($_POST['CustomerID']) && isset ($_POST['CompanyName'])  && isset($_POST['ContactName'])  && isset($_POST['ContactTitle']) && isset($_POST['Address']) && isset($_POST['City']) && isset($_POST['Region']) && isset($_POST['PostalCode']) && isset($_POST['Country']) && isset($_POST['Phone']) && isset($_POST['Fax'])) {
  $CustomerID = $_POST['CustomerID'];
  $CompanyName = $_POST['CompanyName'];
  $ContactName = $_POST['ContactName'];
  $ContactTitle = $_POST['ContactTitle'];
  $Address = $_POST['Address'];
  $City = $_POST['City'];
  $Region = $_POST['Region'];
  $PostalCode = $_POST['PostalCode'];
  $Country = $_POST['Country'];
  $Phone = $_POST['Phone'];
  $Fax = $_POST['Fax'];
  $sql = 'UPDATE customers SET CustomerID=:CustomerID, CompanyName=:CompanyName, ContactName=:ContactName, ContactTitle=:ContactTitle, Address=:Address, City=:City, Region=:Region, PostalCode=:PostalCode, Country=:Country, Phone=:Phone, Fax=:Fax WHERE CustomerID=:CustomerID';
  $statement = $connection->prepare($sql);
  if ($statement->execute([':CustomerID' => $CustomerID, ':CompanyName' => $CompanyName, ':ContactName' => $ContactName, ':ContactTitle' => $ContactTitle,':Address' => $Address,':City' => $City,':Region' => $Region,':PostalCode' => $PostalCode,':Country' => $Country,':Phone' => $Phone,':Fax' => $Fax])) {
    header("Location: /AJAX/PZCustomers/indexCustomer.php");
  }



}


 ?>
<?php require 'headerCustomer.php'; ?>
<div class="container">
  <div class="card mt-5">
    <div class="card-header">
      <h2>Update customer</h2>
    </div>
    <div class="card-body">
      <?php if(!empty($message)): ?>
        <div class="alert alert-success">
          <?= $message; ?>
        </div>
      <?php endif; ?>
      <form method="post">
        <div class="form-group">
          <label for="CustomerID">Customer ID</label>
          <input type="text" value="<?= $customers->CustomerID; ?>" name="CustomerID" id="CustomerID" class="form-control">
        </div>
        <div class="form-group">
          <label for="CompanyName">Company Name</label>
          <input value="<?= $customers->CompanyName; ?>" type="text" name="CompanyName" id="CompanyName" class="form-control">
        </div>
        <div class="form-group">
          <label for="ContactName">Contact Name</label>
          <input type="text" value="<?= $customers->ContactName; ?>" name="ContactName" id="ContactName" class="form-control">
        </div>
        <div class="form-group">
          <label for="ContactTitle">ContactTitle</label>
          <input value="<?= $customers->ContactTitle; ?>" type="text" name="ContactTitle" id="ContactTitle" class="form-control">
        </div>
        <div class="form-group">
          <label for="Address">Address</label>
          <input type="text" value="<?= $customers->Address; ?>" name="Address" id="Address" class="form-control">
        </div><div class="form-group">
          <label for="City">City</label>
          <input value="<?= $customers->City; ?>" type="text" name="City" id="City" class="form-control">
        </div>
        <div class="form-group">
          <label for="Region">Region</label>
          <input type="text" value="<?= $customers->Region; ?>" name="Region" id="Region" class="form-control">
        </div><div class="form-group">
          <label for="PostalCode">Postal Code</label>
          <input value="<?= $customers->PostalCode; ?>" type="text" name="PostalCode" id="PostalCode" class="form-control">
        </div>
        <div class="form-group">
          <label for="Country">Country</label>
          <input type="text" value="<?= $customers->Country; ?>" name="Country" id="Country" class="form-control">
        </div><div class="form-group">
          <label for="Phone">Phone</label>
          <input value="<?= $customers->Phone; ?>" type="text" name="Phone" id="Phone" class="form-control">
        </div>
		<div class="form-group">
          <label for="Fax">Fax</label>
          <input type="text" value="<?= $customers->Fax; ?>" name="Fax" id="Fax" class="form-control">
        <div class="form-group">
          <button type="submit" class="btn btn-info">Update customer</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php require 'footer.php'; ?>