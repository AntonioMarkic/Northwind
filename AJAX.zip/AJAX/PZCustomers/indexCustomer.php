<?php
require 'db.php';
if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM customers  WHERE `CompanyName` LIKE '%".$valueToSearch."%' OR `ContactName` LIKE '%".$valueToSearch."%' ";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM customers";
    //$query = "SELECT * FROM `orders` JOIN `orderdetails` ON `orders.orderNumber=orderdetailes.orderNumber`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "northwind");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

 ?>
<?php require 'headerCustomer.php'; ?>
<div class="container">
  <div class="card mt-5">
    <div class="card-header">
      <h2>All customers</h2>
    </div>
    <div class="card-body">
    
    <form action="indexCustomer.php" method="post" class="form-inline d-flex justify-content-center md-form form-sm">
            <input type="text" name="valueToSearch" id="valueToSearch" placeholder="Unesite podatak za pretragu" class="form-control form-control-sm mr-3 w-75" aria-label="Search">
            <i class="fas fa-search" aria-hidden="true"></i><br><br>
            <input type="submit" name="search" value="Pretraži" class="btn btn-primary"><br><br>
      <table class="table table-bordered">
        <tr>
          <th>Customer ID</th>
          <th>Company Name</th>
          <th>Contact Name</th>
          <th>Contact title</th>
          <th>Address</th>
          <th>Actions</th>
        </tr>
        <?php while($row = mysqli_fetch_array($search_result)):
          ?>
          <tr>
		    <td><?php echo $row['CustomerID'];?></td>
            <td><?php echo $row['CompanyName'];?></td>
            <td><?php echo $row['ContactName'];?></td>
            <td><?php echo $row['ContactTitle'];?></td>
            <td><?php echo $row['Address'];?></td>
            <td>
              <a href="readCustomer.php?CustomerID=<?= $row['CustomerID']; ?>" class="btn btn-success">Read</a>
              <a href="editCustomer.php?CustomerID=<?= $row['CustomerID']; ?>" class="btn btn-info">Edit</a>
              <a onclick="return confirm('Are you sure you want to delete this entry?')" href="deleteCustomer.php?CustomerID=<?= $row['CustomerID']; ?>" class='btn btn-danger'>Delete</a>
            </td>
          </tr>
        <?php endwhile; ?>
      </table>
    </div>
  </div>
</div>
<?php require 'footer.php'; ?>
</body>
</html>
