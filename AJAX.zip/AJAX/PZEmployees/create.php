<?php
require 'db.php';
$message = '';
if (isset($_POST['EmployeeID']) && isset ($_POST['LastName'])  && isset($_POST['FirstName'])  && isset($_POST['Title']) && isset($_POST['TitleOfCourtesy']) && isset($_POST['BirthDate']) && isset($_POST['HireDate']) && isset($_POST['Address'])&& isset($_POST['City']) && isset($_POST['Region']) && isset($_POST['Photo'])) {
  $EmployeeID = $_POST['EmployeeID'];
  $LastName = $_POST['LastName'];
  $FirstName = $_POST['FirstName'];
  $Title = $_POST['Title'];
  $TitleOfCourtesy = $_POST['TitleOfCourtesy'];
  $BirthDate = $_POST['BirthDate'];
  $HireDate = $_POST['HireDate'];
  $Address = $_POST['Address'];
  $City = $_POST['City'];
  $Region = $_POST['Region'];
  $Photo = $_POST['Photo'];
  $sql = 'INSERT INTO employees(EmployeeID,LastName, FirstName, Title, TitleOfCourtesy, BirthDate, HireDate, Address, City, Region, Photo) VALUES(:EmployeeID, :LastName, :FirstName, :Title, :TitleOfCourtesy, :BirthDate, :HireDate, :Address, :City, :Region, :Photo)';
  $statement = $connection->prepare($sql);
  if ($statement->execute([':EmployeeID' => $EmployeeID, ':LastName' => $LastName, ':FirstName' => $FirstName, ':Title' => $Title,':TitleOfCourtesy' => $TitleOfCourtesy,':BirthDate' => $BirthDate,':HireDate' => $HireDate,':Address' => $Address,':City' => $City,':Region' => $Region,':Photo' => $Photo])) {
    $message = 'data inserted successfully';
  }



}


 ?>
<?php require 'headerEmployee.php'; ?>
<div class="container">
  <div class="card mt-5">
    <div class="card-header">
      <h2>Create employee</h2>
    </div>
    <div class="card-body">
      <?php if(!empty($message)): ?>
        <div class="alert alert-success">
          <?= $message; ?>
        </div>
      <?php endif; ?>
      <form method="post">
        <div class="form-group">
          <label for="EmployeeID">Employee ID</label>
          <input type="text"  name="EmployeeID" id="EmployeeID" class="form-control">
        </div>
        <div class="form-group">
          <label for="LastName">Last Name</label>
          <input type="text" name="LastName" id="LastName" class="form-control">
        </div>
        <div class="form-group">
          <label for="FirstName">First Name</label>
          <input type="text" name="FirstName" id="FirstName" class="form-control">
        </div>
        <div class="form-group">
          <label for="Title">Title</label>
          <input type="text" name="Title" id="Title" class="form-control">
        </div>
        <div class="form-group">
          <label for="TitleOfCourtesy">Title of courtesy</label>
          <input type="text" name="TitleOfCourtesy" id="TitleOfCourtesy" class="form-control">
        </div><div class="form-group">
          <label for="BirthDate">Birth Date</label>
          <input type="text" name="BirthDate" id="BirthDate" class="form-control">
        </div>
        <div class="form-group">
          <label for="HireDate">Hire Date</label>
          <input type="text" name="HireDate" id="HireDate" class="form-control">
        </div><div class="form-group">
          <label for="Address">Address</label>
          <input type="text" name="Address" id="Address" class="form-control">
        </div><div class="form-group">
          <label for="City">City</label>
          <input type="text" name="City" id="City" class="form-control">
        </div>
        <div class="form-group">
          <label for="Region">Region</label>
          <input type="text" name="Region" id="Region" class="form-control">
        </div><div class="form-group">
          <label for="Photo">Photo</label>
          <input type="file" name="Photo" id="Photo"  accept="image/* class="form-control">
        </div>		
        <div class="form-group">
          <button type="submit" class="btn btn-info">Create employee</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php require 'footer.php'; ?>