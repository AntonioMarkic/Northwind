<?php
require 'db.php';
$EmployeeID = $_GET['EmployeeID'];
$sql = 'SELECT * FROM employees WHERE EmployeeID=:EmployeeID';
$statement = $connection->prepare($sql);
$statement->execute([':EmployeeID' => $EmployeeID ]);
$employees = $statement->fetch(PDO::FETCH_OBJ);
if (isset($_POST['EmployeeID']) && isset ($_POST['LastName'])  && isset($_POST['FirstName'])  && isset($_POST['Title']) && isset($_POST['TitleOfCourtesy']) && isset($_POST['BirthDate']) && isset($_POST['HireDate']) && isset($_POST['Address']) && isset($_POST['City']) && isset($_POST['Region'])) {
  $EmployeeID = $_POST['EmployeeID'];
  $LastName = $_POST['LastName'];
  $FirstName = $_POST['FirstName'];
  $Title = $_POST['Title'];
  $TitleOfCourtesy = $_POST['TitleOfCourtesy'];
  $BirthDate = $_POST['BirthDate'];
  $HireDate = $_POST['HireDate'];
  $Address = $_POST['Address'];
  $City = $_POST['City'];
  $Region = $_POST['Region'];
  $sql = 'UPDATE employees SET EmployeeID=:EmployeeID, LastName=:LastName, FirstName=:FirstName, Title=:Title, TitleOfCourtesy=:TitleOfCourtesy, BirthDate=:BirthDate, HireDate=:HireDate, Address=:Address, City=:City, Region=:Region WHERE EmployeeID=:EmployeeID';
  $statement = $connection->prepare($sql);
  if ($statement->execute([':EmployeeID' => $EmployeeID, ':LastName' => $LastName, ':FirstName' => $FirstName, ':Title' => $Title,':TitleOfCourtesy' => $TitleOfCourtesy,':BirthDate' => $BirthDate,':HireDate' => $HireDate,':Address' => $Address,':City' => $City,':Region' => $Region])) {
    header("Location: /AJAX/PZEmployees/indexEmployee.php");
  }



}


 ?>
<?php require 'headerEmployee.php'; ?>
<div class="container">
  <div class="card mt-5">
    <div class="card-header">
      <h2>Update employee</h2>
    </div>
    <div class="card-body">
      <?php if(!empty($message)): ?>
        <div class="alert alert-success">
          <?= $message; ?>
        </div>
      <?php endif; ?>
      <form method="post">
        <div class="form-group">
          <label for="EmployeeID">EmployeeID</label>
          <input type="text" value="<?= $employees->EmployeeID; ?>" name="EmployeeID" id="EmployeeID" class="form-control">
        </div>
        <div class="form-group">
          <label for="LastName">LastName</label>
          <input value="<?= $employees->LastName; ?>" type="text" name="LastName" id="LastName" class="form-control">
        </div>
        <div class="form-group">
          <label for="FirstName">FirstName</label>
          <input type="text" value="<?= $employees->FirstName; ?>" name="FirstName" id="FirstName" class="form-control">
        </div>
        <div class="form-group">
          <label for="Title">Title</label>
          <input value="<?= $employees->Title; ?>" type="text" name="Title" id="Title" class="form-control">
        </div>
        <div class="form-group">
          <label for="TitleOfCourtesy">TitleOfCourtesy</label>
          <input type="text" value="<?= $employees->TitleOfCourtesy; ?>" name="TitleOfCourtesy" id="TitleOfCourtesy" class="form-control">
        </div><div class="form-group">
          <label for="BirthDate">Birth Date</label>
          <input value="<?= $employees->BirthDate; ?>" type="text" name="BirthDate" id="BirthDate" class="form-control">
        </div>
        <div class="form-group">
          <label for="HireDate">Hire Date</label>
          <input type="text" value="<?= $employees->HireDate; ?>" name="HireDate" id="HireDate" class="form-control">
        </div><div class="form-group">
          <label for="Address">Address</label>
          <input value="<?= $employees->Address; ?>" type="text" name="Address" id="Address" class="form-control">
        </div>
        <div class="form-group">
          <label for="City">City</label>
          <input type="text" value="<?= $employees->City; ?>" name="City" id="City" class="form-control">
        </div><div class="form-group">
          <label for="Region">Region</label>
          <input value="<?= $employees->Region; ?>" type="text" name="Region" id="Region" class="form-control">
        </div>
        <div class="form-group">
          <button type="submit" class="btn btn-info">Update employee</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php require 'footer.php'; ?>