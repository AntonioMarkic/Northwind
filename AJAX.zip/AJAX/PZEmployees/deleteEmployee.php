<?php
require 'db.php';
$EmployeeID = $_GET['EmployeeID'];
$sql = 'DELETE FROM employees WHERE EmployeeID=:EmployeeID';
$statement = $connection->prepare($sql);
if ($statement->execute([':EmployeeID' => $EmployeeID])) {
  header("Location: /AJAX/PZEmployees/indexEmployee.php");
}