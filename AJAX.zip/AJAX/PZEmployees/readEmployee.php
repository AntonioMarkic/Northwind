<?php
require 'db.php';
$EmployeeID = $_GET['EmployeeID'];
$sql = 'SELECT * FROM employees WHERE EmployeeID=:EmployeeID';
$statement = $connection->prepare($sql);
$statement->execute([':EmployeeID' => $EmployeeID ]);
$row = $statement->fetch(PDO::FETCH_OBJ);
 ?>
<?php require 'headerEmployee.php'; ?>
<div class="container">
  <div class="card mt-5">
    <div class="card-header">
      <h2>Employee:</h2>
    </div>
    <div class="card-body">
      <?php if(!empty($message)): ?>
        <div class="alert alert-success">
          <?= $message; ?>
        </div>
      <?php endif; ?>
      <form method="post">
        <div class="form-group">
          <h2 class="text">EmployeeID: <?= $row->EmployeeID;?></h2>
        </div>
        <div class="form-group">
          <h2 class="text">Last Name: <?= $row->LastName; ?></h2>
        </div>
        <div class="form-group">
          <h2 class="text">First Name: <?=$row->FirstName;  ?></h2>
        </div>
		<div class="form-group">
          <h2 class="text">Title: <?=$row->Title;  ?></h2>
        </div>
        <div class="form-group">
          <h2 class="text">Title of Courtesy: <?= $row->TitleOfCourtesy; ?></h2>
        </div>
        <div class="form-group">
          <h2 class="text">Birth Date: <?= $row->BirthDate; ?></h2>
        </div><div class="form-group">
          <h2 class="text">Hire Date: <?= $row->HireDate; ?></h2>
        </div>
        <div class="form-group">
          <h2 class="text">Address: <?= $row->Address; ?></h2>
		<div class="form-group">
          <h2 class="text">City: <?= $row->City; ?></h2>
		<div class="form-group">
          <h2 class="text">Region: <?= $row->Region; ?></h2>
		  <div class="form-group">
          <h2 class="text">Photo: <?= '<img src="data:image/jpeg;base64,'.base64_encode( $row->Photo ).'"/>' ?></h2>
      </form>
    </div>
  </div>
</div>
<?php require 'footer.php'; ?>
