<?php
require 'db.php';
if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM employees  WHERE `LastName` LIKE '%".$valueToSearch."%' OR `FirstName` LIKE '%".$valueToSearch."%' ";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM employees";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "northwind");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

 ?>
<?php require 'headerEmployee.php'; ?>
<div class="container">
  <div class="card mt-5">
    <div class="card-header">
      <h2>All employees</h2>
    </div>
    <div class="card-body">
    
    <form action="indexEmployee.php" method="post" class="form-inline d-flex justify-content-center md-form form-sm">
            <input type="text" name="valueToSearch" id="valueToSearch" placeholder="Unesite podatak za pretragu" class="form-control form-control-sm mr-3 w-75" aria-label="Search">
            <i class="fas fa-search" aria-hidden="true"></i><br><br>
            <input type="submit" name="search" value="Pretraži" class="btn btn-primary"><br><br>
      <table class="table table-bordered">
        <tr>
          <th>Employee ID</th>
          <th>Last Name</th>
          <th>First Name</th>
          <th>Title</th>
          <th>Title of Courtesy</th>
          <th>Actions</th>
        </tr>
        <?php while($row = mysqli_fetch_array($search_result)):
          ?>
          <tr>
		    <td><?php echo $row['EmployeeID'];?></td>
            <td><?php echo $row['LastName'];?></td>
            <td><?php echo $row['FirstName'];?></td>
            <td><?php echo $row['Title'];?></td>
            <td><?php echo $row['TitleOfCourtesy'];?></td>
            <td>
              <a href="readEmployee.php?EmployeeID=<?= $row['EmployeeID']; ?>" class="btn btn-success">Read</a>
              <a href="editEmployee.php?EmployeeID=<?= $row['EmployeeID']; ?>" class="btn btn-info">Edit</a>
              <a onclick="return confirm('Are you sure you want to delete this entry?')" href="deleteEmployee.php?EmployeeID=<?= $row['EmployeeID']; ?>" class='btn btn-danger'>Delete</a>
            </td>
          </tr>
        <?php endwhile; ?>
      </table>
    </div>
  </div>
</div>
<?php require 'footer.php'; ?>
</body>
</html>
